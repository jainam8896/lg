@include('admin.index')
<link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
<div class="container mt-3">
    <h1 class="text-center">Edit Brand</h1>
    <form action="{{URL('editBranddata')}}" method="post" class="text-center">
        @csrf
        <div class="form-outline mb-4 w-50 m-auto">
            <label for="brand_title" class="form-label">Brand Title</label>
            <input type="hidden" name="brand_edit_id" value="{{$data->brand_id}}">
            <input type="text" name="brand_title" id="brand_title" class="form-control" required="required" value="{{$data->brand_title}}">
        </div>
        <input type="submit" value="Update Brand" class="btn btn-outline-success px-3 mb-3" name="edit_brands">
    </form>
</div>