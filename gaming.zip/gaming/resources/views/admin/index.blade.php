<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
    <script src="../js//bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

    <style>
        .admin_image {
            width: 100px;
            object-fit: contain;
        }
        .footer{
            position: absolute;
            bottom: 0;
        }
        .product_img{
            width: 100px;
            object-fit: contain;
        }
    </style>

</head>

<body>
    <div class="container-fluid p-0">

        <div class="bg-light">
            <h3 class="text-center p-2">Admin Details</h3>
        </div>

        <div class="row">
            <div class="col-md-12 p-1 d-flex align-items-center">
                <div class="p-3">
                    <a href="#"><img src="../img/gamSet.jpg" alt="" class="admin_image"></a>
                    <p class="text-light text-center">Admin Name</p>
                </div>
                <div class="button text-center">
                    <a href="{{URL('admindashboard')}}"><button class="btn btn-outline-primary">Dashboard</button></a>
                    <a href="{{URL('admininsert')}}"><button class="btn btn-outline-primary">Insert Product</button></a>
                    <a href="{{URL('adminviewproduct')}}"><button class="btn btn-outline-primary">View Product</button></a>
                    <a href="{{URL('admiinsertcat')}}"><button class="btn btn-outline-primary">Insert Categories</button></a>
                    <a href="{{URL('adminviewcat')}}"><button class="btn btn-outline-primary">View Categories</button></a>
                    <a href="{{URL('admiinsertbrand')}}"><button class="btn btn-outline-primary">Insert Brands</button></a>
                    <a href="{{URL('adminviewbrand')}}"><button class="btn btn-outline-primary">View Brands</button></a>
                    <a href="index.php?list_user"><button class="btn btn-outline-primary">List User</button></a>
                    <!-- <a href="index.php?all_order"><button class="btn btn-outline-primary">All Orders</button></a> -->
                    <a href="logout.php"><button class="btn btn-outline-primary">Logout</button></a>
                </div>
            </div>
        </div>

        <div>
            <h1 class="text-center">Welcome Admin</h1>
        </div>
        <hr/>

        <div class="container my-3">

        </div>

        <!-- <div class="bg-info p-3 text-center footer">
            <p>All rights @- Designed By Jainam Shah-2023</p>
        </div> -->

        
    
    </div>
</body>

</html>