<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login and Sign Up form</title>
    <link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('customcss/s1.css')}}">
    <link rel="stylesheet" href="../s1.css">
</head>

<body>
    <div class="wrapper">
        <h1>Admin Login</h1>
        <form action="" method="post">
            <input type="text" name="email" id="email" placeholder="Email">
            <input type="password" name="password" id="password" placeholder="Password">
            <button type="submit" name="submit">Login</button>
        </form>
    </div>
</body>

</html>