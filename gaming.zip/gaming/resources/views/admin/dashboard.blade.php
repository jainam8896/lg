@include('admin.index')
<link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
<h3 class="text-center text-success">Dashboard</h3>
<div class="row mt-5">
    <div class="col-xl-3 col-md-6">
        <div class="card bg-dark text-light" style="width: 18rem;">
            <!-- <img src="..." class="card-img-top" alt="..."> -->
            <div class="card-body">
                <h5 class="card-title text-center">Total Product</h5>
                
                <a href="index.php?view_product" class="btn btn-outline-success" style="margin-top: 20px;margin-left: 64px;">View Product</a>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6" style="margin-left:30px;">
        <div class="card bg-dark text-light" style="width: 18rem;">
        <!-- <img src="..." class="card-img-top" alt="..."> -->
            <div class="card-body">
                <h5 class="card-title text-center">Total cat</h5>
                
                <a href="index.php?view_categories" class="btn btn-outline-success" style="margin-top: 20px;margin-left: 64px;">View Categories</a>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6" style="margin-left:30px;">
        <div class="card bg-dark text-light" style="width: 18rem;">
        <!-- <img src="..." class="card-img-top" alt="..."> -->
            <div class="card-body">
                <h5 class="card-title text-center">Total Brand</h5>
               
                <a href="index.php?view_brands" class="btn btn-outline-success" style="margin-top: 20px;margin-left: 71px;">View Brands</a>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mt-10" style="margin-left:30px;">
        <div class="card bg-dark text-light" style="width: 18rem; margin-top: 28px;margin-left: 287px;">
        <!-- <img src="..." class="card-img-top" alt="..."> -->
            <div class="card-body">
                <h5 class="card-title text-center">Total User</h5>
                
                <a href="index.php?view_brands" class="btn btn-outline-success" style="margin-top: 20px;margin-left: 71px;">View Brands</a>
            </div>
        </div>
    </div>
</div>