@include('admin.index')
<link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
<h2 class="text-center text-success">Insert Categories</h2>
<form method="post" action="{{URL('adminaddcat')}}"  class="mb-2">
    @csrf
    <div class="input-group w-50 m-auto">
        <input type="text" class="form-control" name="cart_title" placeholder="Insert Categories" aria-label="Categories" aria-describedby="basic-addon1" required>
    </div>
    <div class="input-group w-10 mb-2 m-auto">
        <button type="submit" class="btn btn-outline-success p-2 my-3 m-auto" name="insert_cart" value="Insert Categories" style="margin-left: 585px;">Insert cat</button>
    </div>
</form>