@include('admin.index')
<link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
<div class="container mt-3">
    <h1 class="text-center">Edit Category</h1>
    <form action="{{URL('editCategorydata')}}" method="post" class="text-center">
        @csrf
        <div class="form-outline mb-4 w-50 m-auto">
            <label for="category_title" class="form-label">Category Title</label>
            <input type="hidden" name="cat_edit_id" value="{{$data->cat_id}}">
            <input type="text" name="category_title" id="category_title" class="form-control" required="required" value="{{$data->cat_title}}">
        </div>
        <input type="submit" value="Update category" class="btn btn-outline-success px-3 mb-3" name="edit_cat">
    </form>
</div>