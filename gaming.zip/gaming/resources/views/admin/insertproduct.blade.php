<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insert Product</title>
    <link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
</head>

<body class="bg-light">
    <div class="container mt-3">
        <h1 class="text-center">Insert Product</h1>
        <form method="post" action="{{URL('addproduct')}}" enctype="multipart/form-data">
            @csrf
            <div class="form-outline mb-4 w-50 m-auto">
                <label for="product_title" class="form-label">Product Title</label>
                <input type="text" name="product_title" id="product_title" class="form-control" placeholder="Enter Product title" autocomplete="off" required="required">
            </div>

            <div class="form-outline mb-4 w-50 m-auto">
                <label for="description" class="form-label">Product Description</label>
                <input type="text" name="description" id="description" class="form-control" placeholder="Enter Product description" autocomplete="off" required="required">
            </div>


            <div class="form-outline mb-4 w-50 m-auto">
                <select id="Cat" name="cat_id" class="form-select" aria-placeholder="Select cat">
                    <option value="" >Select Category</option>
                        @if ($categories != null)
                            @foreach ($categories as $item)
                                <option value="{{$item->cat_id}}">{{$item->cat_title}}</option>
                            @endforeach
                        @else
                            <option>No Data Found...</option>
                        @endif
                </select>
            </div>

            <div class="form-outline mb-4 w-50 m-auto">
                <select id="brand" name="brand_id" class="form-select">
                    <option value="">Select Brands</option>
                    @if ($brands != null)
                        @foreach ($brands as $item)
                            <option value="{{$item->brand_id}}">{{$item->brand_title}}</option>
                        @endforeach
                    @else
                        <option>No Data Found...</option>
                    @endif
                </select>
            </div>

            <div class="form-outline mb-4 w-50 m-auto">
                <label for="product_image" class="form-label">Product Image </label>
                <input type="file" name="image" id="product_image" class="form-control" required="required">
            </div>

            <div class="form-outline mb-4 w-50 m-auto">
                <label for="product_qty" class="form-label">Product Qty </label>
                <input type="number" name="product_qty" id="product_qty" class="form-control" required="required">
            </div>

            <div class="form-outline mb-4 w-50 m-auto">
                <label for="product_price" class="form-label">Product Price</label>
                <input type="number" name="product_price" id="product_price" class="form-control" placeholder="Enter Product Price" autocomplete="off" required="required">
            </div>

            <div class="form-outline mb-4 w-50 m-auto">
                <input type="submit" name="insert_product" class="btn btn-outline-success mb-3 px-3" value="Insert Product">
            </div>

        </form>
    </div>

</body>

</html>