@include('admin.index')
<link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
<div class="container mt-5">
    <h1 class="text-center">Edit Product</h1>
    <form action="{{URL('editProductData')}}" method="post" enctype="multipart/form-data">
        @csrf
        <input type="hidden" name="pid" value="{{$data->product_id}}">
        <div class="form-outline w-50 m-auto mb-4">
            <label for="product_title" class="form-label">Product Title</label>
            <input type="text" id="product_title" value="{{$data->product_title}}" name="product_title" class="form-control" required="required">
        </div>
        <div class="form-outline w-50 m-auto mb-4">
            <label for="product_desc" class="form-label">Product Description</label>
            <input type="text" id="product_desc" value="{{$data->product_descripition}}" name="product_desc" class="form-control" required="required">
        </div>
        <div class="form-outline w-50 m-auto mb-4">
        <label for="product_category" class="form-label">Product Category</label>
           <select name="product_category" class="form-select">
           <option value=""></option>
                @if ($category != null)
                    @foreach ($category as $item)
                        <option value="{{$item->cat_id}}" {{ ($data->cat_id == $item->cat_id) ? 'selected' : ''}}>{{$item->cat_title}}</option> 
                    @endforeach
                @else
                    <option>No Data Found...</option>
                @endif
           </select>
        </div>
        <div class="form-outline w-50 m-auto mb-4">
        <label for="product_category" class="form-label">Product Brands</label>
           <select name="product_brands" class="form-select">
           <option value=""></option>
                @if ($brand != null)
                    @foreach ($brand as $item)
                        <option value="{{$item->brand_id}}" {{ ($data->brand_id == $item->brand_id) ? 'selected' : ''}}>{{$item->brand_title}}</option> 
                    @endforeach
                @else
                    <option>No Data Found...</option>
                @endif
           </select>
        </div>
        <div class="form-outline w-50 m-auto mb-4">
            <label for="product_image1" class="form-label">Product Image</label>
            <div class="d-flex">
            <input type="hidden" name="old_img" value="{{$data->product_img}}">
            <input type="file" id="product_image" name="product_image" class="form-control w-90 m-auto" required="required">
            <img src="{{asset('image/'.$data->product_img)}}" alt="" class="product_img" height="100" width="100">
            </div>
        </div>
        <div class="form-outline w-50 m-auto mb-4">
            <label for="product_qty" class="form-label">Product Qty</label>
            <input type="number" id="product_qty" value="{{$data->product_qty}}" name="product_qty" class="form-control" required="required">
        </div>
        <div class="form-outline w-50 m-auto mb-4">
            <label for="product_price" class="form-label">Product Price</label>
            <input type="text" id="product_price" value="{{$data->product_price}}" name="product_price" class="form-control" required="required">
        </div>
        <div class="w-50 m-auto">
            <input type="submit" name="edit_product" value="Update Product" class="btn btn-outline-success px-3 mb-3">
        </div>
    </form>
</div>
