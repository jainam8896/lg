<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
    <script src="./js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />
    <link rel="stylesheet" href="./style.css">
</head>

<body>
    @include('user.header')
    <div class="container-fluid p-0">
        <div class="row px-1">
            <div class="col-md-10">
                <div class="row">
                    @if ($data != null)
                        @foreach ($data as $item)
                        <div class="card" style="width: 18rem;">
                        <img src="{{asset('image/'.$item->product_img)}}" class="card-img-top" alt="{{$item->product_title}}">
                        <div class="card-body">
                          <h5 class="card-title">{{$item->product_title}}</h5>
                          <p class="card-text">{{$item->product_descripition}}</p>
                          <div class="container">
                            <span class="text-success fw-bold fs-4">RS. {{$item->product_price}}</span>
                          </div>
                          <form action="{{URL('addtocart')}}" method="POST">
                            @csrf
                            <input type="hidden" name="pid" value="{{$item->product_id}}">
                            <input type="hidden" name="cartQty" value="1">
                           
                            <button type="submit" class="btn btn-outline-primary add-cart" name="add-cart">Add To Cart</button>
                        </form>
                        </div>
                    </div>
                    @endforeach
                    @endif
                </div>
            </div>
            <div class="col-md-2 bg-secondary p-0">
                <ul class="navbar-nav me-auto text-center">
                    <li class="nav-item bg-info">
                        <h4>Brand</h4>
                        <hr/>
                        @if($getbrand != null)
                            @foreach($getbrand as $item)
                        <a href="{{URL('home?brand='.$item->brand_id)}}" class="nav-link text-light">
                            <h5>{{$item->brand_title}}</h5>
                        </a>
                        @endforeach
                        @endif
                    </li>  
                </ul>
                <ul class="navbar-nav me-auto text-center">
                    <li class="nav-item bg-info">
                        <hr/>
                        <h4>Categories</h4>
                        <hr/>
                        @if($getcat != null)
                            @foreach($getcat as $item)
                        <a href="{{URL('home?cat='.$item->cat_id)}}" class="nav-link text-light">
                            <h5>{{$item->cat_title}}</h5>
                        </a>
                        @endforeach
                        @endif
                    </li>
                </ul>
            </div>
        </div>
    </div>
    @include('user.footer')
</body>
</html>