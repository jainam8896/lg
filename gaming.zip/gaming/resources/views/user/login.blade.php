<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login and Sign Up form</title>
    <link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('customcss/s1.css')}}">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../s1.css">
</head>

<body>
    <div class="wrapper">
        <h1>Login</h1>
        <form action="login" method="post">
            @csrf
            <input type="text" name="username" id="username" placeholder="Email">
            <input type="password" name="password" id="password" placeholder="Password">
            <button type="submit" name="submit" class="btn btn-outline-primary" style="width: 176px;">Login</button>
        </form>
        <div class="member">
             Not a member? <a href="{{URL('userreg')}}">
                 Register Now
             </a>
        </div>
    </div>
</body>

</html>