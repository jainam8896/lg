<!DOCTYPE html>
<html lang="en">
    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login and Sign Up form</title>
    <link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('customcss/s1.css')}}">
    <link rel="stylesheet" href="../s1.css">
    <link rel="stylesheet" href="../css/bootstrap.min.css">
</head>

<body>
    <div class="wrapper">
        <h1>Sign Up</h1>
        <form action="register" method="post">
            @csrf
            <input type="text" name="username" id="username" placeholder="Username" required>
            <input type="text" name="email" id="email" placeholder="Email" required>
            <input type="password" name="password" id="password" placeholder="Password" required>
            <input type="password" name="confirmpassword" id="confirmpassword" placeholder="Confirm Password" required>
            <button type="submit" name="submit" class="btn btn-outline-success" style="width: 137px;margin-top: 20px">Sign UP</button>
        </form>
        <div class="member">
             Already a member? <a href="{{URL('userlogin')}}">
                 Login Here
             </a>
        </div>
    </div>
</body>
</html>