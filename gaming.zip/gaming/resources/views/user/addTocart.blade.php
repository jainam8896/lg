@include('user.header')
<link rel="stylesheet" href="{{asset('bootstrap/css/bootstrap.css')}}">
<h3 class="text-center">Add To Cart</h3>
        <table class="table table-bordered mt-5">
            <thead>
                <tr class="text-center">
                    <th >Product ID</th>
                    <th >Product Image</th>
                    <th >Product Name</th>
                    <th >Qty</th>
                    <th >Product Price</th>
                    <th >Total</th>
                    <th >delete</th>
                </tr>
                @if ($countCat > 0)
                @php
                    $i=1;
                @endphp
                @foreach($product as $item)
            </thead>
            <tbody class="text-center">  
                <td>{{$i++}}</td>
                <td><img src="{{asset('image/'.$item->product_img)}}" class="shadow" alt="Product's" height="100px" width="120px"></td>
                <td>{{$item->product_title}}</td>
                <td><button type="submit" name="DBOperation" value="-" class="btn btn-outline-danger">-</button>{{$item->qty}}<button type="submit" name="DBOperation" value="+" class="btn btn-outline-success">+</button></td>
                <td>{{$item->product_price}}</td>    
                <td>{{$item->product_price * $item->qty}}</td>
                <td><button type="submit" class="btn btn-outline-danger" name="del">Delete</button></td> 
            </tbody>
            @endforeach
            @endif
            
        </table>
        <div class="float-end">
            <a href="" class="btn btn-outline-primary fw-bold fs-5">Check Out</a>
        </div>
    
