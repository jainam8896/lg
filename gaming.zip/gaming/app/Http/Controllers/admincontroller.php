<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class admincontroller extends Controller
{
    //
    function addcat(Request $req)
    {
        $ctitle=$req->cart_title;

        DB::table('tb_cat')->insert(["cat_title"=>$ctitle]);
        echo "<script>alert('Cat Added');</script>";
        // return view('admin/insertcat');
        return redirect('adminviewcat');
    }
    
    function addbrand(Request $req)
    {
        $btitle=$req->brand_title;

        DB::table('tb_brand')->insert(["brand_title"=>$btitle]);
        echo "<script>alert('brand Added');</script>";
        return redirect('');
    }

    function loadAddproduct(Request $req)
    {
        $cat = $this->getcat();
        $brand = $this->getbrand();
        return view('admin.insertproduct',['categories'=>$cat,'brands'=>$brand]);
    }

    function loadviewcat(Request $req)
    {
        $cat = $this->getcat();
        $countCat = count($cat);
        return view('admin.viewcat',['categories'=>$cat,"countCat"=>$countCat]);
    }

    function loadviewbrand(Request $req)
    {
        $brand = $this->getbrand();
        $countCat = count($brand);
        return view('admin.viewbrand',['brands'=>$brand,"countCat"=>$countCat]);
    }

    function loadproduct(Request $req)
    {
        $product = $this->getproduct();
        $countCat = count($product);
        return view('admin.viewproduct',['products'=>$product,"countCat"=>$countCat]);
    }

    function getcat()
    {
        $cat = DB::table('tb_cat')->get();
        return $cat;
    }
    function getbrand()
    {
        $brand = DB::table('tb_brand')->get();
        return $brand;
    }

    function getproduct()
    {
        $product = DB::table('tb_product')->get();
        return $product;
    }

    function editCategory ($id) {
        $data = DB::table('tb_cat')->where('cat_id',$id)->get();
        $finalData = $data[0];
        return view('admin.editcat',["data"=>$finalData]);
    }

    function editCategoryData(Request $req)
    {
        DB::table('tb_cat')->where('cat_id',$req->cat_edit_id)->update(["cat_title"=>$req->category_title]);
        return redirect('adminviewcat');
    }

    function editbrand ($id) {
        $data = DB::table('tb_brand')->where('brand_id',$id)->get();
        $finalData = $data[0];
        return view('admin.editbrand',["data"=>$finalData]);
    }

    function editBrandData(Request $req)
    {
        DB::table('tb_brand')->where('brand_id',$req->brand_edit_id)->update(["brand_title"=>$req->brand_title]);
        return redirect('adminviewbrand');
    }

    function deleteCat($id)
    {
        DB::table('tb_cat')->where('cat_id',$id)->delete();
        return redirect('adminviewcat');
    }

    function deleteBrand($id)
    {
        DB::table('tb_brand')->where('brand_id',$id)->delete();
        return redirect('adminviewcat');
    }

    function addProduct(Request $req)
    {
        $ptitle = $req->product_title;
        $pdesc = $req->description;
        $cat = $req->cat_id;
        $brand= $req->brand_id;
        $baseName = $req->image->getClientOriginalName();
        $ext = $req->image->getClientOriginalExtension();
        $newfileName = md5($baseName).rand(1111,9999).".".$ext;
        $req->image->move(public_path('image'),$newfileName);
        $pqty = $req->product_qty;
        $pprice = $req->product_price;


        DB::table('tb_product')->insert(["product_title"=>$ptitle,"product_descripition"=>$pdesc,"cat_id"=>$cat,"brand_id"=>$brand,"product_img"=>$newfileName,"product_qty"=>$pqty,"product_price"=>$pprice]);
    }

    function editProduct ($id) {
        $category = DB::table('tb_cat')->get();
        $brand = DB::table('tb_brand')->get();
        $data = DB::table('tb_product')->where('product_id',$id)->get();
        $finalProduct = $data[0];
        return view('admin.editproduct',["data"=>$finalProduct,"category"=>$category,"brand"=>$brand]);
    }

    function editProductdata(Request $req)
    {
        $ptitle = $req->product_title;
        $pdesc = $req->product_desc;
        $cat = $req->product_category;
        $brand = $req->product_brands;
        if($req->hasfile('product_image'))
        {
            $baseName = $req->product_image->getClientOriginalName();
            $ext = $req->product_image->getClientOriginalExtension();
            $newfileName = md5($baseName).rand(1111,9999).".".$ext;
            $req->product_image->move(public_path('image'),$newfileName);
        }
        else
        {
            $newfileName = $req->old_img;
        }
        $pqty = $req->product_qty;
        $pprice = $req->product_price;

        DB::table('tb_product')->where('product_id',$req->pid)->update(["product_title"=>$ptitle,"product_descripition"=>$pdesc,"cat_id"=>$cat,"brand_id"=>$brand,"product_img"=>$newfileName,"product_qty"=>$pqty,"product_price"=>$pprice]);
        return redirect('adminviewproduct');
    }

    function deleteProduct ($id) {
        DB::table('tb_product')->where('product_id',$id)->delete();
        return redirect('adminviewproduct');
    }
}
