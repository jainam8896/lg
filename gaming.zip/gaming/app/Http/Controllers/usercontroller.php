<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class usercontroller extends Controller
{
    //
    function registerIns(Request $req){
        $Name = $req->username;
        $Email = $req->email;
        $pd = $req->password;
        $CPassword = $req->confirmpassword;

        if(strcmp($pd,$CPassword)==0)
        {
            DB::table('tb_user')->insert(["username"=>$Name,"email"=>$Email,"password"=>$pd]);
            // return redirect('/login');
            echo "<script>alert('Inserted success')</script>";
        }
        else
        {
            echo "<script>alert('Inserted Fail')</script>";
        }
        return view('user.login');
    }

    function loginIns(Request $req){
        $data = DB::table('tb_user')->where(["username"=>$req->username,"password"=>$req->password])->get();   
        if(count($data)===0)
        {
            return view('user.login');
        }
        else
        {
            session()->put("username",$data[0]->username);
            session()->put("userid",$data[0]->id);
            return redirect('home');
        }
    }

    function home (Request $req) {
        $data = DB::table('tb_product')->get();
        $getcat= DB::table('tb_cat')->get();
        $getbrand = DB::table('tb_brand')->get();
        if($req->has('cat'))
        {
            $data = DB::table('tb_product')->where(["cat_id"=>$req->query('cat')])->get();
        }
        if($req->has('brand'))
        {
            $data = DB::table('tb_product')->where(["brand_id"=>$req->query('brand')])->get();
        }
        return view('user.index',["data"=>$data,"getcat"=>$getcat,"getbrand"=>$getbrand]);
    }

    function addTocart(Request $req){
        if(session()->has('userid'))
        {
            DB::table('tb_cart')->insert(["user_id"=>session()->get('userid'),'product_id'=>$req->pid,'qty'=>$req->cartQty]);
            return redirect('home');
        }
        else{
            return redirect('userlogin');
        }
    }

    function loadAddtocart(Request $req){
        $product = DB::table('tb_cart')->join('tb_product','tb_cart.product_id','=','tb_product.product_id')->where(["tb_cart.user_id"=>session()->get('userid')])->get();                        
        $countCat = count($product);
        return view('user.addTocart',["product"=>$product,"countCat"=>$countCat]);
    }

    function logout(){
        Session()->flush();
        return redirect('home');
    }
}
