<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\admincontroller;
use App\Http\Controllers\usercontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('admin.dashboard');
});
Route::get('/userheader', function () {
    return view('user.header');
});
Route::get('/userreg', function () {
    return view('user.reg');
});
Route::get('/userlogin', function () {
    return view('user.login');
});
Route::get('/userabout', function () {
    return view('user.about');
});
Route::get('/adminindex', function () {
    return view('admin.index');
});
Route::get('/admindashboard', function () {
    return view('admin.dashboard');
});
Route::get('/admiinsertcat', function () {
    return view('admin.insertcat');
});
Route::get('/admiinsertbrand', function () {
    return view('admin.insertbrand');
});
Route::get('/adminviewbrand', function () {
    return view('admin.viewbrand');
});
Route::get('/admineditproduct', function () {
    return view('admin.editproduct');
});
Route::get('/adminlogin', function () {
    return view('admin.adminlogin');
});


Route::post('adminaddcat',[admincontroller::class,'addcat']);
Route::post('adminaddbrand',[admincontroller::class,'addbrand']);
Route::get('/admininsert',[admincontroller::class,'loadAddproduct']);
Route::post('addproduct',[admincontroller::class,'addProduct']);
Route::get('/adminviewcat',[admincontroller::class,'loadviewcat']);
Route::get('/adminviewbrand',[admincontroller::class,'loadviewbrand']);
Route::get('/adminviewproduct',[admincontroller::class,'loadproduct']);
Route::get('/editCategory/{id?}',[admincontroller::class,'editCategory']);
Route::post('/editCategorydata',[admincontroller::class,'editCategoryData']);
Route::get('/editbrand/{id?}',[admincontroller::class,'editbrand']);
Route::post('/editBranddata',[admincontroller::class,'editBrandData']);
Route::get('/admindeleteCat/{id?}',[admincontroller::class,'deleteCat']);
Route::get('/admindeleteBrand/{id?}',[admincontroller::class,'deleteBrand']);
Route::get('/editProduct/{id?}',[admincontroller::class,'editProduct']);
Route::post('/editProductData',[admincontroller::class,'editProductdata']);
Route::get('/deleteProduct/{id?}',[admincontroller::class,'deleteProduct']);


Route::post('/register',[usercontroller::class,'registerIns']);
Route::post('/login',[usercontroller::class,'loginIns']);
Route::get('/home',[userController::class,'home']);
Route::get('/getbrand',[userController::class,'getbrand']);
Route::post('/addtocart',[usercontroller::class,'addTocart']);
Route::get('/addtoCart',[userController::class,'loadAddtocart']);
Route::get('/logout',[usercontroller::class,'logout']);
